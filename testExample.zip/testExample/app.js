var express = require('express');
var app = express();
var path = require('path');

var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');

//import server info
 var config = require('./bin/config');
//import db connection
 var connection = require('./bin/dbconnection');

//controller of requests
 var controller = require('./app/authrouts');

//middlewares
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', controller);







var server = app.listen(8000, function () {  
    var host = server.address().address  
      var port = server.address().port  
    console.log("Example app listening at http://%s:%s", host, port)  
    }) 