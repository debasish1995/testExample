var con = require('../../bin/dbconnection');

module.exports= function(req, res) {
    var query0 = con.query('SELECT * FROM testexample.skills', function (err, result) {
        if(result){
            res.status(200);
            // res.send(result);
            res.send(200, {status:200,response:result});

        }else{
            res.status(500);
            res.json(500, {status:500, message: 'Internal server error' });
        }
    });
};
