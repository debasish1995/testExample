var con = require('../../bin/dbconnection');
const uuidV1 = require('uuid/v1');


module.exports= function(req, res) {
    console.log(req.body.name);
    var uuid= uuidV1();
    console.log(req.body);
    if(!req.body.name){
        res.send('provide all the fields');
    }
    else {
        var query0 = con.query('SELECT * FROM skills where name = '+JSON.stringify(req.body.name), function (err, result) {
            console.log('start');
            if(result.length == 0 ) {
                var value = {
                    id: uuid,
                    name: req.body.name,
                    status: 1
                };
                
                var query1 = con.query('INSERT INTO `testexample`.`skills` set ?', value, function (err, result) {
                    console.log(query1);
                    if(err){
                        console.log(err);
                        res.status(500);
                        res.json(500, { error: err })
                    }
                    if(result) {
                        res.status(200);
                        res.json(200, {status: 200, message: 'Skill Added successfully!!'});
                    
                    }
                });

            }else{
                res.status(412);
                res.json(412, {status:412, message: 'Skill already Used!!' });
            }
        });
    }
};
