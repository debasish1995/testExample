var con = require('../../bin/dbconnection');

module.exports = function (req, res) {

    if (!req.body.id || !req.body.name) {
        res.send(400, { status: 400, result: 'provide all the fields' });
        //res.send('provide all the fields');
    }
    else {

        var query = con.query('SELECT * FROM testexample.skills where `id`=' + JSON.stringify(req.body.id), (err, result) => {

            if (result) {
                if (result.length > 0) {
                    var query0 = con.query('UPDATE `testexample`.`skills` SET `name`=' + JSON.stringify(req.body.name) + ' WHERE `id`=' + JSON.stringify(req.body.id), function (err, result) {
                        console.log('start');
                        if (result) {
                            res.status(200);
                            // res.send(result);
                            res.send(200, { status: 200, result: result });

                        } else {
                            console.log("inner");
                            res.status(500);
                            res.json(500, { status: 500, message: 'Internal server error' });
                        }
                    });
                } else {
                    res.json(404, { status: 404, message: 'ID NOT FOUND' });
                }
            } else {
                console.log("outer" + err);
                res.status(500);
                res.json(500, { status: 500, message: 'Internal server error' });
            }
        });



    }

};
