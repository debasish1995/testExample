var con = require('../../bin/dbconnection');

module.exports= function(req, res) {
    console.log(req.body.name);
    var query0 = con.query('select * from skills where name='+JSON.stringify(req.body.name), function (err, result) {
        console.log('start');
        if(result){
            res.status(200);
            // res.send(result);
            res.send(200, {status:200,result:result});

        }else{
            res.status(500);
            res.json(500, {status:500, message: 'Internal server error' });
        }
    });
};
