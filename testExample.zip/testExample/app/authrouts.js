var express = require('express');
var app = express();
var router = express.Router();
var bodyParser = require('body-parser');
router.use(bodyParser.json());
router.use(bodyParser.urlencoded({ extended: true }));
var cookieParser = require('cookie-parser');
router.use(cookieParser());

//const path = require('path');
var config = require('../bin/config');

//////////call all service layer////////////////////
var Skillsearch= require('./utility/Skillsearch');
var Addskill= require('./utility/Addskill');
var Editskill= require('./utility/Editskill');
var Changestatus= require('./utility/Changestatus');
var getSkill= require('./utility/getSkills');
///////router///////////
router.post('/Skillsearch',function(req,res){
    Skillsearch(req,res);
});
router.post('/Addskill',function(req,res){
    Addskill(req,res);
});
router.post('/Editskill',function(req,res){
    Editskill(req,res);
});
router.post('/Changestatus',function(req,res){
    Changestatus(req,res);
});
router.get('/skills',function(req,res){
    getSkill(req,res);
});
/////////////
////////////
module.exports = router;
