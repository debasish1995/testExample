app.controller('testController', function ($scope, $http) {

  $scope.addSkills = {
    "name": "",
    "status": null
  }
  $scope.getAllSkills = function () {
    $http({
      method: 'GET',
      url: "http://localhost:8000/skills"


    }).then(function successCallback(response) {

      $scope.skillList1 = response.data.response;
      console.log(JSON.stringify($scope.skillList1));



    }, function errorCallback(response) {
      alert("Something went wrong.please try again");
    });
  }

  $scope.getAllSkills();

  $scope.addSkillsFctn = function () {
    console.log(JSON.stringify($scope.addSkills));
    $http({
      method: 'POST',
      url: "http://localhost:8000/Addskill",
      data: $scope.addSkills
    }).then(function successCallback(response) {
      $scope.getAllSkills();
      $scope.addSkills = {};
    }, function errorCallback(response) {
      if (response.status == 401) {
        alert("Session Expired. Please Login Again to Continue.");

      }
    });
  }

  $scope.changeStatus = function (index) {
    $http({
      method: 'POST',
      url: "http://localhost:8000/Changestatus",
      data: index
    }).then(function successCallback(response) {
      $scope.getAllSkills();
    }, function errorCallback(response) {
      console.log(JSON.stringify(response));
    });
  }



  $scope.changeSkill = function (obj) {

    $http({
      method: 'POST',
      url: "http://localhost:8000/Editskill",
      data: obj
    }).then(function successCallback(response) {
      $scope.getAllSkills();
    }, function errorCallback(response) {
      console.log(JSON.stringify(response));
    });

  }
})
